wget https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js
wget https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js
